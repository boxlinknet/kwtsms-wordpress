<?php
/**
 * Admin Controller — menus, settings registration, admin notices.
 *
 * Registers three subpages under a top-level "kwtSMS" menu:
 *   - General Settings  (OTP behaviour, CAPTCHA)
 *   - Gateway Settings  (API credentials, SenderID, balance)
 *   - SMS Templates     (EN + AR templates with character counters)
 *
 * Settings are registered via the WordPress Settings API with sanitize callbacks.
 * Scripts and styles are enqueued only on plugin admin pages.
 *
 * @package KwtSMS_OTP
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class KwtSMS_Admin
 */
class KwtSMS_Admin {

	/**
	 * Plugin manager.
	 *
	 * Protected so admin view files included inside methods can access it via $this.
	 *
	 * @var KwtSMS_Plugin
	 */
	protected $plugin;

	/**
	 * Admin page hook suffixes (used to scope asset enqueuing).
	 *
	 * @var string[]
	 */
	private $page_hooks = array();

	/**
	 * Flag set during ajax_logout_gateway() to signal that sanitize_gateway_settings()
	 * should pass the raw value through unchanged (used to write the cleared state
	 * without the sanitizer re-reading stale DB values and overriding it).
	 *
	 * @var bool
	 */
	private $clearing_credentials = false;

	/**
	 * Constructor.
	 *
	 * @param KwtSMS_Plugin $plugin Plugin manager.
	 */
	public function __construct( KwtSMS_Plugin $plugin ) {
		$this->plugin = $plugin;

		add_action( 'admin_menu', array( $this, 'register_menus' ) );
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_init', array( $this, 'handle_log_exports' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_notices', array( $this, 'show_admin_notices' ) );
		add_action( 'wp_dashboard_setup', array( $this, 'register_dashboard_widget' ) );
		add_action( 'wp_ajax_kwtsms_get_coverage', array( $this, 'ajax_get_coverage' ) );
		add_action( 'wp_ajax_kwtsms_logout_gateway', array( $this, 'ajax_logout_gateway' ) );
	}

	// =========================================================================
	// Menu registration
	// =========================================================================

	/**
	 * Register the top-level admin menu and subpages.
	 */
	public function register_menus() {
		$this->page_hooks[] = add_menu_page(
			__( 'kwtSMS', 'wp-kwtsms' ),
			__( 'kwtSMS', 'wp-kwtsms' ),
			'manage_options',
			'kwtsms-otp',
			array( $this, 'render_general_page' ),
			'dashicons-format-chat',
			80
		);

		$this->page_hooks[] = add_submenu_page(
			'kwtsms-otp',
			__( 'General Settings', 'wp-kwtsms' ),
			__( 'General', 'wp-kwtsms' ),
			'manage_options',
			'kwtsms-otp',
			array( $this, 'render_general_page' )
		);

		$this->page_hooks[] = add_submenu_page(
			'kwtsms-otp',
			__( 'Gateway Settings', 'wp-kwtsms' ),
			__( 'Gateway', 'wp-kwtsms' ),
			'manage_options',
			'kwtsms-otp-gateway',
			array( $this, 'render_gateway_page' )
		);

		$this->page_hooks[] = add_submenu_page(
			'kwtsms-otp',
			__( 'SMS Templates', 'wp-kwtsms' ),
			__( 'Templates', 'wp-kwtsms' ),
			'manage_options',
			'kwtsms-otp-templates',
			array( $this, 'render_templates_page' )
		);

		$this->page_hooks[] = add_submenu_page(
			'kwtsms-otp',
			__( 'Integrations', 'wp-kwtsms' ),
			__( 'Integrations', 'wp-kwtsms' ),
			'manage_options',
			'kwtsms-otp-integrations',
			array( $this, 'render_integrations_page' )
		);

		// Conditionally register sub-pages for each active integration.
		$integrations_active = array(
			'woo'       => class_exists( 'WooCommerce' ),
			'cf7'       => class_exists( 'WPCF7' ),
			'wpforms'   => function_exists( 'wpforms' ) || class_exists( 'WPForms\WPForms' ),
			'elementor' => did_action( 'elementor/loaded' ) || class_exists( '\Elementor\Plugin' ),
			'gf'        => class_exists( 'GFForms' ),
			'nf'        => class_exists( 'Ninja_Forms' ),
		);

		$int_labels = array(
			'woo'       => __( 'WooCommerce', 'wp-kwtsms' ),
			'cf7'       => __( 'Contact Form 7', 'wp-kwtsms' ),
			'wpforms'   => __( 'WPForms', 'wp-kwtsms' ),
			'elementor' => __( 'Elementor', 'wp-kwtsms' ),
			'gf'        => __( 'Gravity Forms', 'wp-kwtsms' ),
			'nf'        => __( 'Ninja Forms', 'wp-kwtsms' ),
		);

		foreach ( $integrations_active as $key => $active ) {
			if ( ! $active ) {
				continue;
			}
			$this->page_hooks[] = add_submenu_page(
				'kwtsms-otp',
				/* translators: %s: integration name (e.g. WooCommerce) */
				sprintf( __( '%s Settings', 'wp-kwtsms' ), $int_labels[ $key ] ),
				'&#8627; ' . $int_labels[ $key ],
				'manage_options',
				'kwtsms-otp-int-' . $key,
				array( $this, 'render_int_' . $key . '_page' )
			);
		}

		$this->page_hooks[] = add_submenu_page(
			'kwtsms-otp',
			__( 'kwtSMS Logs', 'wp-kwtsms' ),
			__( 'Logs', 'wp-kwtsms' ),
			'manage_options',
			'kwtsms-otp-logs',
			array( $this, 'render_logs_page' )
		);

		$this->page_hooks[] = add_submenu_page(
			'kwtsms-otp',
			__( 'kwtSMS Help & Support', 'wp-kwtsms' ),
			__( 'Help', 'wp-kwtsms' ),
			'manage_options',
			'kwtsms-otp-help',
			array( $this, 'render_help_page' )
		);
	}

	// =========================================================================
	// Settings registration
	// =========================================================================

	/**
	 * Register all plugin settings with the WordPress Settings API.
	 *
	 * Sanitize callbacks ensure no unsafe data is stored.
	 */
	public function register_settings() {
		// ----- General settings -----
		register_setting(
			'kwtsms_otp_general_group',
			'kwtsms_otp_general',
			array(
				'sanitize_callback' => array( $this, 'sanitize_general_settings' ),
			)
		);

		add_settings_section(
			'kwtsms_general_otp_behavior',
			__( 'OTP Behaviour', 'wp-kwtsms' ),
			'__return_null',
			'kwtsms_general_settings'
		);

		add_settings_section(
			'kwtsms_general_captcha',
			__( 'CAPTCHA Protection', 'wp-kwtsms' ),
			'__return_null',
			'kwtsms_general_settings'
		);

		// ----- Gateway settings -----
		register_setting(
			'kwtsms_otp_gateway_group',
			'kwtsms_otp_gateway',
			array(
				'sanitize_callback' => array( $this, 'sanitize_gateway_settings' ),
			)
		);

		// ----- Template settings -----
		register_setting(
			'kwtsms_otp_templates_group',
			'kwtsms_otp_templates',
			array(
				'sanitize_callback' => array( $this, 'sanitize_template_settings' ),
			)
		);

		// ----- Integration settings -----
		register_setting(
			'kwtsms_otp_integrations_group',
			'kwtsms_otp_integrations',
			array(
				'sanitize_callback' => array( $this, 'sanitize_integrations_settings' ),
			)
		);
	}

	// =========================================================================
	// Sanitize callbacks
	// =========================================================================

	/**
	 * Sanitize general settings.
	 *
	 * @param mixed $raw Raw form input.
	 *
	 * @return array Sanitized settings array.
	 */
	public function sanitize_general_settings( $raw ) {
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$defaults = KwtSMS_Settings::DEFAULTS['general'];

		// Sanitize allowed_countries: must be an array of valid ISO2 codes (2 uppercase letters).
		$allowed_raw = $raw['allowed_countries'] ?? $defaults['allowed_countries'];
		if ( ! is_array( $allowed_raw ) ) {
			// Accept JSON string from hidden input.
			$decoded = json_decode( stripslashes( (string) $allowed_raw ), true );
			$allowed_raw = is_array( $decoded ) ? $decoded : $defaults['allowed_countries'];
		}
		$allowed_countries = array_values(
			array_filter(
				array_map( 'strtoupper', array_map( 'sanitize_text_field', $allowed_raw ) ),
				static function( $code ) {
					return preg_match( '/^[A-Z]{2}$/', $code );
				}
			)
		);
		if ( empty( $allowed_countries ) ) {
			$allowed_countries = $defaults['allowed_countries'];
		}

		// Sanitize default_country_code: must be a 2-letter uppercase ISO2 code.
		$default_cc = strtoupper( sanitize_text_field( $raw['default_country_code'] ?? $defaults['default_country_code'] ) );
		if ( ! preg_match( '/^[A-Z]{2}$/', $default_cc ) ) {
			$default_cc = $defaults['default_country_code'];
		}

		// Sanitize otp_required_roles: allow only role slugs that exist in WP.
		$all_roles        = array_keys( wp_roles()->get_names() );
		$raw_roles        = array_map( 'sanitize_text_field', (array) ( $raw['otp_required_roles'] ?? array() ) );
		$otp_required_roles = array_values( array_intersect( $raw_roles, $all_roles ) );

		return array(
			'otp_mode'             => in_array( $raw['otp_mode'] ?? '', array( '2fa', 'passwordless', 'both' ), true )
				? $raw['otp_mode']
				: $defaults['otp_mode'],
			'otp_length'           => in_array( (int) ( $raw['otp_length'] ?? 6 ), array( 4, 6 ), true )
				? (int) $raw['otp_length']
				: 6,
			'otp_expiry'           => max( 1, min( 30, absint( $raw['otp_expiry'] ?? 5 ) ) ),
			'max_attempts'         => max( 1, min( 10, absint( $raw['max_attempts'] ?? 3 ) ) ),
			'resend_cooldown'      => max( 30, min( 600, absint( $raw['resend_cooldown'] ?? 120 ) ) ),
			'login_otp'            => ! empty( $raw['login_otp'] ) ? 1 : 0,
			'reset_otp'            => ! empty( $raw['reset_otp'] ) ? 1 : 0,
			'captcha_provider'     => in_array( $raw['captcha_provider'] ?? '', array( 'none', 'recaptcha', 'turnstile' ), true )
				? $raw['captcha_provider']
				: 'none',
			'recaptcha_site_key'   => sanitize_text_field( $raw['recaptcha_site_key'] ?? '' ),
			'recaptcha_secret_key' => sanitize_text_field( $raw['recaptcha_secret_key'] ?? '' ),
			'turnstile_site_key'   => sanitize_text_field( $raw['turnstile_site_key'] ?? '' ),
			'turnstile_secret_key' => sanitize_text_field( $raw['turnstile_secret_key'] ?? '' ),
			'referral_link'        => ! empty( $raw['referral_link'] ) ? 1 : 0,
			'default_country_code' => $default_cc,
			'allowed_countries'    => $allowed_countries,
			'debug_logging'        => ! empty( $raw['debug_logging'] ) ? 1 : 0,
			'blocked_phones'       => sanitize_textarea_field( wp_unslash( $raw['blocked_phones'] ?? '' ) ),
			'otp_required_roles'   => $otp_required_roles,
			'welcome_sms_enabled'  => ! empty( $raw['welcome_sms_enabled'] ) ? 1 : 0,
		);
	}

	/**
	 * Sanitize gateway settings.
	 *
	 * @param mixed $raw Raw form input.
	 *
	 * @return array Sanitized settings array.
	 */
	public function sanitize_gateway_settings( $raw ) {
		if ( ! is_array( $raw ) ) {
			return array();
		}

		// During ajax_logout_gateway() the flag is set to write the cleared state
		// directly without the sanitizer re-reading and overriding stale DB values.
		if ( $this->clearing_credentials ) {
			return $raw;
		}

		// test_phone is intentionally not persisted — the field has no name attribute.
		$test_phone = '';

		// Warn if the API username looks like a phone number.
		$api_username_raw = sanitize_text_field( $raw['api_username'] ?? '' );
		if ( ! empty( $api_username_raw ) && preg_match( '/^\+?[\d\s()\-]{8,}$/', $api_username_raw ) ) {
			add_settings_error(
				'kwtsms_otp_gateway',
				'phone_as_username',
				__( 'API Username appears to be a phone number. Please enter your kwtSMS API username, not your phone number. Sign up at kwtsms.com to obtain API access.', 'wp-kwtsms' ),
				'warning'
			);
		}

		// Preserve credentials_verified flag only if the credentials are unchanged.
		$current_gw       = get_option( 'kwtsms_otp_gateway', array() );
		$api_password_raw = sanitize_text_field( $raw['api_password'] ?? '' );

		// The password input is never pre-populated in the HTML (security: prevent
		// the plaintext credential appearing in page source / browser history).
		// An empty submission means "keep the stored password unchanged".
		if ( '' === $api_password_raw ) {
			$api_password_raw = $current_gw['api_password'] ?? '';
		}

		$creds_unchanged  = (
			$api_username_raw === ( $current_gw['api_username'] ?? '' ) &&
			$api_password_raw === ( $current_gw['api_password'] ?? '' )
		);

		if ( $creds_unchanged ) {
			// Prefer an explicit value in $raw (the logout AJAX handler sets it to 0).
			// Fall back to the current DB value for plain form POSTs that omit the key.
			$credentials_verified = array_key_exists( 'credentials_verified', $raw )
				? (int) $raw['credentials_verified']
				: (int) ( $current_gw['credentials_verified'] ?? 0 );
		} else {
			$credentials_verified = 0;
		}

		// Carry over previously fetched gateway data.
		// When called from a form POST, $raw only contains the HTML form fields
		// (balance, coverage, sender_ids are absent from the POST body).
		// When called via update_option() from an AJAX handler the full option
		// array is passed as $raw, so we must prefer those values — otherwise
		// the sanitize filter silently overwrites the freshly-fetched data with
		// the old values that were in the DB when the filter fired.
		$sender_ids        = is_array( $raw['sender_ids'] ?? null )
			? (array) $raw['sender_ids']
			: (array) ( $current_gw['sender_ids'] ?? array() );
		$balance_available = array_key_exists( 'balance_available', $raw )
			? $raw['balance_available']
			: ( $current_gw['balance_available'] ?? null );
		$balance_purchased = array_key_exists( 'balance_purchased', $raw )
			? $raw['balance_purchased']
			: ( $current_gw['balance_purchased'] ?? null );
		$balance_updated   = array_key_exists( 'balance_updated_at', $raw )
			? (int) $raw['balance_updated_at']
			: (int) ( $current_gw['balance_updated_at'] ?? 0 );
		$coverage          = is_array( $raw['coverage'] ?? null )
			? (array) $raw['coverage']
			: (array) ( $current_gw['coverage'] ?? array() );
		$sender_id_out     = sanitize_text_field( $raw['sender_id'] ?? '' );

		// Auto-verify when credentials are new or changed.
		if ( ! $creds_unchanged && ! empty( $api_username_raw ) && ! empty( $api_password_raw ) ) {
			$api               = new KwtSMS_API( $api_username_raw, $api_password_raw, false );
			$sender_ids_result = $api->get_sender_ids();

			if ( is_wp_error( $sender_ids_result ) ) {
				add_settings_error(
					'kwtsms_otp_gateway',
					'credentials_invalid',
					sprintf(
						/* translators: %s: error message from kwtSMS API */
						__( 'API credentials could not be verified: %s', 'wp-kwtsms' ),
						$sender_ids_result->get_error_message()
					),
					'error'
				);
			} else {
				$credentials_verified = 1;
				$sender_ids           = $sender_ids_result;

				// Auto-select first sender ID if none was previously saved.
				if ( empty( $sender_id_out ) && ! empty( $sender_ids ) ) {
					$sender_id_out = $sender_ids[0];
				}

				$balance_result    = $api->get_balance();
				$coverage_result   = $api->get_coverage();

				if ( ! is_wp_error( $balance_result ) ) {
					$balance_available = $balance_result['available'];
					$balance_purchased = $balance_result['purchased'];
					$balance_updated   = time();
				}
				if ( ! is_wp_error( $coverage_result ) ) {
					$coverage = (array) $coverage_result;
				}

				add_settings_error(
					'kwtsms_otp_gateway',
					'credentials_verified',
					__( 'API credentials verified successfully.', 'wp-kwtsms' ),
					'success'
				);
			}
		}

		return array(
			'api_username'         => $api_username_raw,
			'api_password'         => $api_password_raw,
			'sender_id'            => $sender_id_out,
			'test_mode'            => ! empty( $raw['test_mode'] ) ? 1 : 0,
			'test_phone'           => $test_phone,
			'credentials_verified' => $credentials_verified,
			'sender_ids'           => $sender_ids,
			'balance_available'    => $balance_available,
			'balance_purchased'    => $balance_purchased,
			'balance_updated_at'   => $balance_updated,
			'coverage'             => $coverage,
		);
	}

	/**
	 * Sanitize template settings.
	 *
	 * Strips HTML tags and emojis from message templates.
	 *
	 * @param mixed $raw Raw form input.
	 *
	 * @return array Sanitized settings array.
	 */
	public function sanitize_template_settings( $raw ) {
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$sanitized = array();
		$allowed_keys = array( 'login_otp', 'reset_otp', 'welcome_sms' );

		foreach ( $allowed_keys as $key ) {
			if ( ! isset( $raw[ $key ] ) || ! is_array( $raw[ $key ] ) ) {
				continue;
			}

			$template = $raw[ $key ];
			$sanitized[ $key ] = array(
				'enabled' => ! empty( $template['enabled'] ) ? 1 : 0,
				'en'      => $this->sanitize_template_content( $template['en'] ?? '' ),
				'ar'      => $this->sanitize_template_content( $template['ar'] ?? '' ),
			);
		}

		return $sanitized;
	}

	/**
	 * Sanitize integration settings.
	 *
	 * Handles both boolean enable flags and template content arrays.
	 * Uses the currently saved option as a base so that saving one
	 * integration's sub-form does not wipe the settings of others.
	 * The hidden `_save_section` field identifies which sub-form was
	 * submitted; 'all' (or absent) means the legacy full-page form.
	 *
	 * @param mixed $raw Raw form input.
	 *
	 * @return array Sanitized settings array.
	 */
	public function sanitize_integrations_settings( $raw ) {
		if ( ! is_array( $raw ) ) {
			return array();
		}

		// Start from currently saved values so that saving one integration's
		// sub-form does not wipe the other integrations' settings.
		$current = get_option( 'kwtsms_otp_integrations', array() );
		if ( ! is_array( $current ) ) {
			$current = array();
		}

		// _save_section identifies which integration sub-form was submitted.
		// 'all' or empty means the legacy full-page form — sanitize everything.
		$section = sanitize_key( $raw['_save_section'] ?? 'all' );

		$valid_modes = array( 'notification', 'gate' );

		$allowed_statuses  = array_map( 'sanitize_key', array(
			'processing', 'on-hold', 'completed', 'cancelled',
			'pending', 'refunded', 'failed',
		) );
		$raw_notify        = $raw['woo_notify_admin_statuses'] ?? array();
		$notify_admin_statuses = array_values(
			array_filter(
				(array) $raw_notify,
				function ( $s ) use ( $allowed_statuses ) {
					return in_array( sanitize_key( $s ), $allowed_statuses, true );
				}
			)
		);

		// Use current saved values as base; overwrite only the submitted section.
		$sanitized = $current;

		$update_woo       = in_array( $section, array( 'all', 'woo' ), true );
		$update_cf7       = in_array( $section, array( 'all', 'cf7' ), true );
		$update_wpforms   = in_array( $section, array( 'all', 'wpforms' ), true );
		$update_elementor = in_array( $section, array( 'all', 'elementor' ), true );
		$update_gf        = in_array( $section, array( 'all', 'gf' ), true );
		$update_nf        = in_array( $section, array( 'all', 'nf' ), true );

		if ( $update_woo ) {
			$sanitized['woo_enabled']              = ! empty( $raw['woo_enabled'] ) ? 1 : 0;
			$sanitized['woo_checkout_otp']         = ! empty( $raw['woo_checkout_otp'] ) ? 1 : 0;
			$sanitized['woo_admin_phone']          = sanitize_text_field( wp_unslash( $raw['woo_admin_phone'] ?? '' ) );
			$sanitized['woo_notify_admin_statuses'] = $notify_admin_statuses;
			foreach ( array( 'woo_processing', 'woo_shipped', 'woo_completed', 'woo_cancelled', 'woo_pending', 'woo_refunded', 'woo_failed' ) as $key ) {
				if ( isset( $raw[ $key ] ) && is_array( $raw[ $key ] ) ) {
					$sanitized[ $key ] = array(
						'enabled' => ! empty( $raw[ $key ]['enabled'] ) ? 1 : 0,
						'en'      => $this->sanitize_template_content( $raw[ $key ]['en'] ?? '' ),
						'ar'      => $this->sanitize_template_content( $raw[ $key ]['ar'] ?? '' ),
					);
				}
			}
		}

		if ( $update_cf7 ) {
			$sanitized['cf7_enabled'] = ! empty( $raw['cf7_enabled'] ) ? 1 : 0;
			$sanitized['cf7_mode']    = in_array( $raw['cf7_mode'] ?? '', $valid_modes, true ) ? $raw['cf7_mode'] : 'notification';
			if ( isset( $raw['cf7_confirmation'] ) && is_array( $raw['cf7_confirmation'] ) ) {
				$sanitized['cf7_confirmation'] = array(
					'enabled' => ! empty( $raw['cf7_confirmation']['enabled'] ) ? 1 : 0,
					'en'      => $this->sanitize_template_content( $raw['cf7_confirmation']['en'] ?? '' ),
					'ar'      => $this->sanitize_template_content( $raw['cf7_confirmation']['ar'] ?? '' ),
				);
			}
		}

		if ( $update_wpforms ) {
			$sanitized['wpforms_enabled'] = ! empty( $raw['wpforms_enabled'] ) ? 1 : 0;
			$sanitized['wpforms_mode']    = in_array( $raw['wpforms_mode'] ?? '', $valid_modes, true ) ? $raw['wpforms_mode'] : 'notification';
			if ( isset( $raw['wpforms_confirmation'] ) && is_array( $raw['wpforms_confirmation'] ) ) {
				$sanitized['wpforms_confirmation'] = array(
					'enabled' => ! empty( $raw['wpforms_confirmation']['enabled'] ) ? 1 : 0,
					'en'      => $this->sanitize_template_content( $raw['wpforms_confirmation']['en'] ?? '' ),
					'ar'      => $this->sanitize_template_content( $raw['wpforms_confirmation']['ar'] ?? '' ),
				);
			}
		}

		if ( $update_elementor ) {
			$sanitized['elementor_enabled'] = ! empty( $raw['elementor_enabled'] ) ? 1 : 0;
			$sanitized['elementor_mode']    = in_array( $raw['elementor_mode'] ?? '', $valid_modes, true ) ? $raw['elementor_mode'] : 'notification';
			if ( isset( $raw['elementor_confirmation'] ) && is_array( $raw['elementor_confirmation'] ) ) {
				$sanitized['elementor_confirmation'] = array(
					'enabled' => ! empty( $raw['elementor_confirmation']['enabled'] ) ? 1 : 0,
					'en'      => $this->sanitize_template_content( $raw['elementor_confirmation']['en'] ?? '' ),
					'ar'      => $this->sanitize_template_content( $raw['elementor_confirmation']['ar'] ?? '' ),
				);
			}
		}

		if ( $update_gf ) {
			$sanitized['gf_enabled'] = ! empty( $raw['gf_enabled'] ) ? 1 : 0;
			$sanitized['gf_mode']    = in_array( $raw['gf_mode'] ?? '', $valid_modes, true ) ? $raw['gf_mode'] : 'notification';
			if ( isset( $raw['gf_confirmation'] ) && is_array( $raw['gf_confirmation'] ) ) {
				$sanitized['gf_confirmation'] = array(
					'enabled' => ! empty( $raw['gf_confirmation']['enabled'] ) ? 1 : 0,
					'en'      => $this->sanitize_template_content( $raw['gf_confirmation']['en'] ?? '' ),
					'ar'      => $this->sanitize_template_content( $raw['gf_confirmation']['ar'] ?? '' ),
				);
			}
		}

		if ( $update_nf ) {
			$sanitized['nf_enabled'] = ! empty( $raw['nf_enabled'] ) ? 1 : 0;
			$sanitized['nf_mode']    = in_array( $raw['nf_mode'] ?? '', $valid_modes, true ) ? $raw['nf_mode'] : 'notification';
			if ( isset( $raw['nf_confirmation'] ) && is_array( $raw['nf_confirmation'] ) ) {
				$sanitized['nf_confirmation'] = array(
					'enabled' => ! empty( $raw['nf_confirmation']['enabled'] ) ? 1 : 0,
					'en'      => $this->sanitize_template_content( $raw['nf_confirmation']['en'] ?? '' ),
					'ar'      => $this->sanitize_template_content( $raw['nf_confirmation']['ar'] ?? '' ),
				);
			}
		}

		return $sanitized;
	}

	/**
	 * Strip HTML and emoji from a template string.
	 *
	 * @param string $content Raw template content.
	 *
	 * @return string Clean template.
	 */
	private function sanitize_template_content( $content ) {
		$content = wp_strip_all_tags( sanitize_textarea_field( wp_unslash( $content ) ) );
		// Strip emoji (U+1F000 and above, common emoji blocks).
		$content = preg_replace(
			'/[\x{1F000}-\x{1FFFF}\x{2600}-\x{26FF}\x{2700}-\x{27BF}]/u',
			'',
			$content
		);
		return trim( $content ?? '' );
	}

	// =========================================================================
	// Asset enqueuing
	// =========================================================================

	/**
	 * Enqueue admin CSS and JS only on plugin pages.
	 *
	 * @param string $hook_suffix Current admin page hook suffix.
	 */
	public function enqueue_assets( $hook_suffix ) {
		if ( ! in_array( $hook_suffix, $this->page_hooks, true ) ) {
			return;
		}

		wp_enqueue_style(
			'kwtsms-admin',
			KWTSMS_OTP_URL . 'assets/css/admin.css',
			array(),
			KWTSMS_OTP_VERSION
		);

		if ( is_rtl() ) {
			wp_enqueue_style(
				'kwtsms-admin-rtl',
				KWTSMS_OTP_URL . 'assets/css/admin-rtl.css',
				array( 'kwtsms-admin' ),
				KWTSMS_OTP_VERSION
			);
		}

		wp_enqueue_script(
			'kwtsms-admin',
			KWTSMS_OTP_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			KWTSMS_OTP_VERSION,
			true
		);

		// Resolve default dial code for auto-prefixing short phone numbers in JS.
		$default_iso2  = $this->plugin->settings->get( 'general.default_country_code', 'KW' );
		$all_ccs       = include KWTSMS_OTP_DIR . 'includes/data/country-codes.php';
		$default_dial  = '965'; // Kuwait fallback.
		foreach ( $all_ccs as $cc_row ) {
			if ( $cc_row['iso2'] === $default_iso2 ) {
				$default_dial = $cc_row['dial'];
				break;
			}
		}

		wp_localize_script(
			'kwtsms-admin',
			'kwtSmsAdminData',
			array(
				'ajaxUrl'              => admin_url( 'admin-ajax.php' ),
				'nonce'                => wp_create_nonce( 'kwtsms_admin_nonce' ),
				'credentialsVerified'  => (bool) $this->plugin->settings->get( 'gateway.credentials_verified', false ),
				'defaultDialCode'      => $default_dial,
				'savedSenderIds'      => array_values( (array) $this->plugin->settings->get( 'gateway.sender_ids', array() ) ),
				'savedBalance'        => array(
					'available'  => $this->plugin->settings->get( 'gateway.balance_available', null ),
					'purchased'  => $this->plugin->settings->get( 'gateway.balance_purchased', null ),
					'updated_at' => (int) $this->plugin->settings->get( 'gateway.balance_updated_at', 0 ),
				),
				'savedCoverage'       => array_values( (array) $this->plugin->settings->get( 'gateway.coverage', array() ) ),
				'template_defaults'      => $this->plugin->settings->get_template_defaults_for_js(),
				'placeholder_estimates'  => array(
					'{otp}'            => str_repeat( '0', (int) $this->plugin->settings->get( 'general.otp_length', 6 ) ),
					'{site_name}'      => get_bloginfo( 'name' ),
					'{expiry_minutes}' => (string) (int) $this->plugin->settings->get( 'general.otp_expiry', 10 ),
					'{name}'           => 'User',
					'{customer_name}'  => 'User',
					'{order_id}'       => '12345',
					'{total}'          => '10.000 KWD',
					'{tracking}'       => 'TRK123456',
					'{form_name}'      => 'Contact Form',
					'{phone}'          => '96599220000',
				),
				'strings'              => array(
					'verifying'          => __( 'Verifying...', 'wp-kwtsms' ),
					'verified'           => __( 'Credentials verified!', 'wp-kwtsms' ),
					'error'              => __( 'Verification failed.', 'wp-kwtsms' ),
					'sending'            => __( 'Sending...', 'wp-kwtsms' ),
					'sent'               => __( 'Test SMS sent! Check your phone.', 'wp-kwtsms' ),
					'characters'         => __( 'characters', 'wp-kwtsms' ),
					'smsPages'           => __( 'SMS page(s)', 'wp-kwtsms' ),
					'usernameIsPhone'    => __( 'This looks like a phone number. Your API Username must be your kwtSMS account username — not a phone number. Sign up at kwtsms.com to obtain API credentials.', 'wp-kwtsms' ),
					'loadingCoverage'    => __( 'Loading coverage...', 'wp-kwtsms' ),
					'coverageError'      => __( 'Could not load coverage data.', 'wp-kwtsms' ),
					'credentialsMissing' => __( 'Please enter your API username and password, then click "Save Settings" before performing this action.', 'wp-kwtsms' ),
					/* translators: %s: API username */
				'connectedAs'        => __( 'Connected as %s', 'wp-kwtsms' ),
					'reload'             => __( 'Reload', 'wp-kwtsms' ),
					'reloading'          => __( 'Reloading...', 'wp-kwtsms' ),
					/* translators: %s: total purchased SMS credits */
				'ofPurchased'        => __( '· of %s purchased', 'wp-kwtsms' ),
					'testPhoneMissing'   => __( 'Please enter a test phone number first.', 'wp-kwtsms' ),
					'phoneTooShort'      => __( 'Number is too short. Enter the country code followed by the full local number, e.g. 96512345678 (Kuwait: 965 + 8 digits).', 'wp-kwtsms' ),
					'testModeResult'     => __( 'Test mode ON — message queued in kwtSMS account queue, will not be delivered. Delete to recover credits.', 'wp-kwtsms' ),
					'testSmsResult'      => __( 'SMS delivered to %phone%. Check your messages.', 'wp-kwtsms' ),
					'testSmsFailed'      => __( 'Send failed. Check your API credentials and phone number.', 'wp-kwtsms' ),
					'unsavedTitle'       => __( 'Unsaved Changes', 'wp-kwtsms' ),
					'unsavedBody'        => __( 'You have unsaved changes. Leaving this page will discard them.', 'wp-kwtsms' ),
					'unsavedSave'        => __( 'Save Changes', 'wp-kwtsms' ),
					'unsavedLeave'       => __( 'Leave Page', 'wp-kwtsms' ),
				),
			)
		);
	}

	// =========================================================================
	// Admin notices
	// =========================================================================

	/**
	 * Hook callback for admin_notices — skips plugin pages (they render inline).
	 *
	 * This prevents duplicate rendering: plugin pages call render_page_notices()
	 * directly inside the .wrap div so notices appear before the logo header.
	 */
	public function show_admin_notices() {
		$screen = get_current_screen();
		if ( ! $screen ) {
			return;
		}

		$is_plugin_page = in_array(
			$screen->id,
			array_filter( $this->page_hooks ),
			true
		) || strpos( $screen->id, 'kwtsms' ) !== false;

		// Plugin pages render notices inline (before the logo) — skip here.
		if ( $is_plugin_page ) {
			return;
		}
	}

	/**
	 * Render contextual plugin notices inline.
	 *
	 * Called at the top of every plugin page template, before the logo header,
	 * so notices visually appear above the branding rather than beside it.
	 * Also calls settings_errors() to show Settings API save/validation messages.
	 */
	public function render_page_notices() {
		// Settings API messages (e.g. "Settings saved.", validation errors).
		// Capture output and add 'inline' class so WP admin JS doesn't move
		// these notices to after the <h1> inside our flex header row.
		ob_start();
		settings_errors();
		$se_html = ob_get_clean();
		// WP outputs settings_errors with single-quoted class attr (class='notice ...').
		// Add 'inline' so WP admin JS doesn't relocate the notice into our flex header.
		$se_html = str_replace( "class='notice ", "class='notice inline ", $se_html );
		echo $se_html; // phpcs:ignore WordPress.Security.EscapeOutput

		// Notice: site is not HTTPS — suppressed on localhost/127.0.0.1 dev environments.
		// The 'inline' class prevents WP admin JS from relocating the notice
		// to after the first <h1> (which is inside our flex header row).
		if ( ! is_ssl() ) {
			$home_host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
			$is_local  = ( 'localhost' === $home_host || '127.0.0.1' === $home_host || '::1' === $home_host
							|| 0 === strpos( $home_host, 'localhost' ) );
			if ( ! $is_local ) {
				printf(
					'<div class="notice notice-warning inline"><p><strong>%s</strong> %s</p></div>',
					esc_html__( 'kwtSMS Warning:', 'wp-kwtsms' ),
					esc_html__( 'Your site is not served over HTTPS. OTP codes may be intercepted in transit. Enable SSL for security.', 'wp-kwtsms' )
				);
			}
		}

		// Notice: API credentials not verified (never logged in, or logged out).
		if ( ! $this->plugin->settings->get( 'gateway.credentials_verified', false ) ) {
			printf(
				'<div class="notice notice-error inline"><p><strong>%s</strong> %s <a href="%s">%s</a></p></div>',
				esc_html__( 'kwtSMS:', 'wp-kwtsms' ),
				esc_html__( 'API credentials are not configured. The plugin will not be able to send SMS messages.', 'wp-kwtsms' ),
				esc_url( admin_url( 'admin.php?page=kwtsms-otp-gateway' ) ),
				esc_html__( 'Configure now →', 'wp-kwtsms' )
			);
		}

		// Notice: test mode is active.
		if ( $this->plugin->settings->get( 'gateway.test_mode', 1 ) ) {
			printf(
				'<div class="notice notice-error inline"><p>%s</p></div>',
				esc_html__( 'kwtSMS is in Test Mode. SMS messages will be queued but not delivered. Delete from kwtSMS queue to recover credits.', 'wp-kwtsms' )
			);
		}
	}

	// =========================================================================
	// Page renderers
	// =========================================================================

	/**
	 * Render the General Settings page.
	 */
	public function render_general_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'wp-kwtsms' ) );
		}
		include KWTSMS_OTP_DIR . 'admin/views/page-general.php';
	}

	/**
	 * Render the Gateway Settings page.
	 */
	public function render_gateway_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'wp-kwtsms' ) );
		}
		include KWTSMS_OTP_DIR . 'admin/views/page-gateway.php';
	}

	/**
	 * Render the SMS Templates page.
	 */
	public function render_templates_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'wp-kwtsms' ) );
		}
		include KWTSMS_OTP_DIR . 'admin/views/page-templates.php';
	}

	/**
	 * Render the Integrations admin page.
	 */
	public function render_integrations_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'wp-kwtsms' ) );
		}
		include KWTSMS_OTP_DIR . 'admin/views/page-integrations.php';
	}

	/**
	 * Render WooCommerce integration settings sub-page.
	 */
	public function render_int_woo_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'wp-kwtsms' ) );
		}
		include KWTSMS_OTP_DIR . 'admin/views/page-int-woo.php';
	}

	/**
	 * Render Contact Form 7 integration settings sub-page.
	 */
	public function render_int_cf7_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'wp-kwtsms' ) );
		}
		$int_key = 'cf7';
		include KWTSMS_OTP_DIR . 'admin/views/page-int-form.php';
	}

	/**
	 * Render WPForms integration settings sub-page.
	 */
	public function render_int_wpforms_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'wp-kwtsms' ) );
		}
		$int_key = 'wpforms';
		include KWTSMS_OTP_DIR . 'admin/views/page-int-form.php';
	}

	/**
	 * Render Elementor integration settings sub-page.
	 */
	public function render_int_elementor_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'wp-kwtsms' ) );
		}
		$int_key = 'elementor';
		include KWTSMS_OTP_DIR . 'admin/views/page-int-form.php';
	}

	/**
	 * Render Gravity Forms integration settings sub-page.
	 */
	public function render_int_gf_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'wp-kwtsms' ) );
		}
		$int_key = 'gf';
		include KWTSMS_OTP_DIR . 'admin/views/page-int-form.php';
	}

	/**
	 * Render Ninja Forms integration settings sub-page.
	 */
	public function render_int_nf_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'wp-kwtsms' ) );
		}
		$int_key = 'nf';
		include KWTSMS_OTP_DIR . 'admin/views/page-int-form.php';
	}

	/**
	 * Render the Logs page (SMS History + OTP Attempts).
	 */
	public function render_logs_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'wp-kwtsms' ) );
		}
		include KWTSMS_OTP_DIR . 'admin/views/page-logs.php';
	}

	/**
	 * Render the Help & Support page.
	 */
	public function render_help_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'wp-kwtsms' ) );
		}
		include KWTSMS_OTP_DIR . 'admin/views/page-help.php';
	}

	// =========================================================================
	// AJAX: Coverage
	// =========================================================================

	/**
	 * AJAX handler — fetch SMS coverage data.
	 *
	 * Security: nonce + manage_options capability.
	 */
	public function ajax_get_coverage() {
		check_ajax_referer( 'kwtsms_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'wp-kwtsms' ) ), 403 );
		}

		$coverage = $this->plugin->api->get_coverage();

		if ( is_wp_error( $coverage ) ) {
			wp_send_json_error( array( 'message' => $coverage->get_error_message() ) );
		}

		wp_send_json_success( array( 'coverage' => $coverage ) );
	}

	// =========================================================================
	// AJAX: Logout (clear credentials_verified flag and fetched API data)
	// =========================================================================

	/**
	 * AJAX: Logout — clear verified flag and all data fetched from the API.
	 *
	 * Resets credentials_verified, sender_ids, sender_id, coverage, and
	 * balance so the UI shows a clean state until the user logs in again.
	 *
	 * Security: nonce + manage_options.
	 */
	public function ajax_logout_gateway() {
		check_ajax_referer( 'kwtsms_admin_nonce', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'wp-kwtsms' ) ), 403 );
			return;
		}

		$gw                         = get_option( 'kwtsms_otp_gateway', array() );
		$gw['credentials_verified'] = 0;
		$gw['api_username']         = '';
		$gw['api_password']         = '';
		$gw['sender_ids']           = array();
		$gw['sender_id']            = '';
		$gw['coverage']             = array();
		$gw['balance_available']    = null;
		$gw['balance_purchased']    = null;
		$gw['balance_updated_at']   = 0;

		// Set the flag so sanitize_gateway_settings() passes $gw through unchanged,
		// writing the cleared state without the sanitizer re-reading stale DB values.
		$this->clearing_credentials = true;
		update_option( 'kwtsms_otp_gateway', $gw );
		$this->clearing_credentials = false;

		wp_send_json_success();
	}

	// =========================================================================
	// AJAX: Clear log
	// =========================================================================

	/**
	 * Handle log file download/export requests before any HTML output.
	 *
	 * Hooked on admin_init so Content-Type / Content-Disposition headers can
	 * be sent before WordPress outputs any HTML. Handles three actions:
	 *   - export_csv          — stream SMS history or OTP attempt log as CSV
	 *   - download_debug_log  — stream the debug log file as a download
	 *   - clear_debug_log     — truncate the debug log file then redirect
	 *
	 * Security: capability check + per-action nonce verification on every branch.
	 */
	public function handle_log_exports() {
		if ( ! isset( $_GET['page'] ) || 'kwtsms-otp-logs' !== $_GET['page'] ) {
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$action = isset( $_GET['action'] ) ? sanitize_key( $_GET['action'] ) : '';
		if ( empty( $action ) || ! isset( $_GET['_wpnonce'] ) ) {
			return;
		}

		$debug_log_path   = defined( 'WP_CONTENT_DIR' ) ? WP_CONTENT_DIR . '/kwtsms-debug.log' : '';
		$debug_logging_on = (bool) $this->plugin->settings->get( 'general.debug_logging', 0 );
		$debug_log_exists = $debug_log_path && file_exists( $debug_log_path );
		$show_debug_tab   = $debug_logging_on && $debug_log_exists;

		// ---- Download debug log ----
		if ( 'download_debug_log' === $action && $show_debug_tab &&
			wp_verify_nonce( sanitize_key( wp_unslash( $_GET['_wpnonce'] ) ), 'kwtsms_download_debug_log' )
		) {
			$filename = 'kwtsms-debug-' . gmdate( 'Y-m-d' ) . '.log';
			header( 'Content-Type: text/plain; charset=UTF-8' );
			header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $filename ) . '"' );
			header( 'Pragma: no-cache' );
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents,WordPress.Security.EscapeOutput.OutputNotEscaped
			echo file_get_contents( $debug_log_path );
			exit;
		}

		// ---- Export CSV ----
		if ( 'export_csv' === $action ) {
			$log_key = sanitize_key( $_GET['log'] ?? '' );
			if ( in_array( $log_key, array( 'sms_history', 'attempt_log' ), true ) &&
				wp_verify_nonce( sanitize_key( wp_unslash( $_GET['_wpnonce'] ) ), 'kwtsms_export_csv_' . $log_key )
			) {
				$log = get_option( 'kwtsms_otp_' . $log_key, array() );
				if ( ! is_array( $log ) ) {
					$log = array();
				}

				$filename = 'kwtsms-' . $log_key . '-' . gmdate( 'Y-m-d' ) . '.csv';
				header( 'Content-Type: text/csv; charset=UTF-8' );
				header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $filename ) . '"' );
				header( 'Pragma: no-cache' );

				$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions

				if ( 'sms_history' === $log_key ) {
					fputcsv( $out, array( 'Date/Time', 'Type', 'Phone', 'Message', 'Sender ID', 'Status', 'Result Code', 'Result Message' ) );
					foreach ( $log as $entry ) {
						fputcsv( $out, array(
							gmdate( 'Y-m-d H:i:s', $entry['time'] ?? 0 ),
							$this->csv_safe( $entry['type']                      ?? '' ),
							$this->csv_safe( $entry['phone']                     ?? '' ),
							$this->csv_safe( $entry['message']                   ?? '' ),
							$this->csv_safe( $entry['sender_id']                 ?? '' ),
							$this->csv_safe( $entry['status']                    ?? '' ),
							$this->csv_safe( $entry['gateway_result']['code']    ?? '' ),
							$this->csv_safe( $entry['gateway_result']['message'] ?? '' ),
						) );
					}
				} else {
					fputcsv( $out, array( 'Date/Time', 'User ID', 'Phone', 'IP Address', 'Action', 'Result' ) );
					foreach ( $log as $entry ) {
						$user_id = $entry['user_id'] ?? null;
						fputcsv( $out, array(
							gmdate( 'Y-m-d H:i:s', $entry['time'] ?? 0 ),
							is_null( $user_id ) ? 'N/A' : (int) $user_id,
							$this->csv_safe( $entry['phone']  ?? '' ),
							$this->csv_safe( $entry['ip']     ?? '' ),
							$this->csv_safe( $entry['action'] ?? '' ),
							$this->csv_safe( $entry['result'] ?? '' ),
						) );
					}
				}

				fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				exit;
			}
		}
	}

	// =========================================================================
	// Dashboard Widget
	// =========================================================================

	/**
	 * Register the kwtSMS dashboard widget.
	 */
	public function register_dashboard_widget() {
		wp_add_dashboard_widget(
			'kwtsms_otp_dashboard_widget',
			__( 'kwtSMS', 'wp-kwtsms' ),
			array( $this, 'render_dashboard_widget' )
		);
	}

	/**
	 * Render the kwtSMS dashboard widget.
	 */
	public function render_dashboard_widget() {
		$log = get_option( 'kwtsms_otp_send_log', array() );
		if ( ! is_array( $log ) ) {
			$log = array();
		}

		$today_count  = 0;
		$today_start  = strtotime( 'today midnight' );
		$failed_count = 0;

		foreach ( $log as $entry ) {
			if ( isset( $entry['time'] ) && $entry['time'] >= $today_start ) {
				$today_count++;
				if ( 'failed' === ( $entry['status'] ?? '' ) ) {
					$failed_count++;
				}
			}
		}

		$test_mode = (bool) $this->plugin->settings->get( 'gateway.test_mode', false );
		?>
		<div style="padding:4px 0;">
			<?php if ( $test_mode ) : ?>
			<p style="background:#fff3cd;border-left:3px solid #FFA200;padding:6px 10px;margin:0 0 10px;">
				<?php esc_html_e( 'Test mode is active.', 'wp-kwtsms' ); ?>
			</p>
			<?php endif; ?>

			<p>
				<strong><?php esc_html_e( 'OTPs sent today:', 'wp-kwtsms' ); ?></strong>
				<?php echo (int) $today_count; ?>
				<?php if ( $failed_count > 0 ) : ?>
				<span style="color:#dc3232;">(<?php echo (int) $failed_count; ?> <?php esc_html_e( 'failed', 'wp-kwtsms' ); ?>)</span>
				<?php endif; ?>
			</p>

			<?php if ( ! empty( $log ) ) : ?>
			<table style="width:100%;font-size:12px;border-collapse:collapse;">
				<thead>
					<tr>
						<th style="text-align:left;padding:2px 4px;border-bottom:1px solid #ddd;"><?php esc_html_e( 'Time', 'wp-kwtsms' ); ?></th>
						<th style="text-align:left;padding:2px 4px;border-bottom:1px solid #ddd;"><?php esc_html_e( 'Phone', 'wp-kwtsms' ); ?></th>
						<th style="text-align:left;padding:2px 4px;border-bottom:1px solid #ddd;"><?php esc_html_e( 'Sender ID', 'wp-kwtsms' ); ?></th>
						<th style="text-align:left;padding:2px 4px;border-bottom:1px solid #ddd;"><?php esc_html_e( 'Status', 'wp-kwtsms' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( array_slice( $log, 0, 5 ) as $entry ) : ?>
					<tr>
						<td style="padding:2px 4px;"><?php echo esc_html( date_i18n( get_option( 'time_format' ), $entry['time'] ?? 0 ) ); ?></td>
						<td style="padding:2px 4px;"><?php echo esc_html( $entry['phone'] ?? '' ); ?></td>
						<td style="padding:2px 4px;"><?php echo esc_html( $entry['sender_id'] ?? '' ); ?></td>
						<td style="padding:2px 4px;color:<?php echo 'sent' === ( $entry['status'] ?? '' ) ? '#46b450' : '#dc3232'; ?>;">
							<?php echo 'sent' === ( $entry['status'] ?? '' ) ? esc_html__( 'Sent', 'wp-kwtsms' ) : esc_html__( 'Failed', 'wp-kwtsms' ); ?>
						</td>
					</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
			<p style="margin:6px 0 0;"><a href="<?php echo esc_url( admin_url( 'admin.php?page=kwtsms-otp-gateway' ) ); ?>"><?php esc_html_e( 'View full log →', 'wp-kwtsms' ); ?></a></p>
			<?php endif; ?>
		</div>
		<?php
	}

	// =========================================================================
	// Helpers
	// =========================================================================

	/**
	 * Sanitise a string value for CSV export, neutralising spreadsheet formula injection.
	 *
	 * Cells starting with =, +, -, or @ are interpreted as formulas by Excel and
	 * LibreOffice Calc. Prefixing them with a tab character prevents execution while
	 * keeping the value readable.
	 *
	 * @param string $value Raw cell value.
	 * @return string Safe cell value.
	 */
	private function csv_safe( $value ) {
		$value = (string) $value;
		if ( '' !== $value && in_array( $value[0], array( '=', '+', '-', '@' ), true ) ) {
			$value = "\t" . $value;
		}
		return $value;
	}
}
